// Justin McBurnie
//10-7-15
//Expression Assignments

var wage = prompt("Please Enter Wage: ");
var hoursWorked = prompt("Enter hours worked:");
var numberOfWeeks =[];
var basePay =(wage * hoursWorked);

numberOfWeeks[0] = prompt("Number of weeks worked: ");
monthPay    =(basePay * numberOfWeeks);
payTotal= (monthPay);
alert("Your total gross pay for the month will be "+'$'+ payTotal+".");
console.log("Your total gross pay for the month will be "+'$'+ payTotal+".");

//I tried 15 for wage, 35 hours worked, 2 weeks
//I tried 20 for wage  50, 4 weeks
//I did 14.15 for wage 40 hours worked, and 4 weeks payed for.
//I did 35 wage 50 hours 4 weeks


