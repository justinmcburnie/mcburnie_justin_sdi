/*justin mcburnie
week3 worksheet*/

/*var mpg = prompt("Please enter vehicles MPG:"); //mpg of the vehicle
var gasGauge =prompt("Please enter gasGauge in percent. Write as decimal.:");//current gas gauge with percent writeen as deciaml
var tankCapicity =prompt("Please enter gas tank capacity:");//fuel tank capacity
totalMiles =    (mpg * tankCapicity);//total miles on full tank
milesLeft =    Number(totalMiles * gasGauge - 20);// total miles left - 20 miles just to be safe



    if(milesLeft <= 200) {
        console.log("You only have" +" "+ milesLeft +" "+ "gallons of gas in your tank, better get gas now while you can!");
    }else{
        console.log("Yes, you can make it without stopping for gas!");
    }
*/

var timeMovie = prompt("Enter Time of Movie.:");
var age       = prompt("Enter Age:.");

if (age >= 55 || age <= 10) {

   console.log("Ticket price is $77");
}else{
    console.log("Ticket price is $12");
}

if (3 === timeMovie || timeMovie <= 5) {
    console.log("Ticket Price is $7.");
}else{
    console.log("Ticket price is $12");
}